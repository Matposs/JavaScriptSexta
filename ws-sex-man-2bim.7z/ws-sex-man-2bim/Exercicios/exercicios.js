const console = require('../extras/console');

//Exercicio 01 

function exercicio01(){

        const numero = console.getNumber("Informe o número: ");

        if (numero > 10){
            console.log("Número maior do que 10!")
        }
            else if (numero == 10){
                console.log("Número igual a 10!")
            }
            else {
                console.log("Número menor do que 10!")
            }
}
exercicio01 ();

